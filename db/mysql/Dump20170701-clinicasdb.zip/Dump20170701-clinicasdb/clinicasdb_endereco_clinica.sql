-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: clinicasdb
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `endereco_clinica`
--

DROP TABLE IF EXISTS `endereco_clinica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `endereco_clinica` (
  `id_endereco` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `rua` varchar(255) DEFAULT NULL,
  `bairro` varchar(55) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `complemento` varchar(55) DEFAULT NULL,
  `cep` varchar(55) DEFAULT NULL,
  `id_cidade` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_endereco`),
  KEY `fk_endereco_clinica_cidade1_idx` (`id_cidade`),
  CONSTRAINT `fk_endereco_clinica_cidade1` FOREIGN KEY (`id_cidade`) REFERENCES `cidade` (`id_cidade`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `endereco_clinica`
--

LOCK TABLES `endereco_clinica` WRITE;
/*!40000 ALTER TABLE `endereco_clinica` DISABLE KEYS */;
INSERT INTO `endereco_clinica` VALUES (1,'mimi','mimi',155555,'mimi','88.888-888',4500),(2,'mimi','mimi',1200,'mimi','',4549),(4,NULL,NULL,NULL,NULL,NULL,NULL),(5,'mimi','mimi',500,'mimi','55.555-555',4500),(6,' ',' ',1200,'mimi',' ',4500),(7,'mimi','mimi',12,'mimi','22.222-222',4660),(8,'','',NULL,'','34.444-444',NULL),(9,'','',NULL,'','11.111-111',4440),(10,'','',NULL,'','',NULL),(11,'','',NULL,'','',NULL);
/*!40000 ALTER TABLE `endereco_clinica` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-01 14:14:18

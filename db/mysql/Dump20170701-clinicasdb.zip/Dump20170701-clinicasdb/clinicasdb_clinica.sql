-- MySQL dump 10.13  Distrib 5.7.12, for Win64 (x86_64)
--
-- Host: localhost    Database: clinicasdb
-- ------------------------------------------------------
-- Server version	5.7.17-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `clinica`
--

DROP TABLE IF EXISTS `clinica`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clinica` (
  `id_clinica` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `razao_social` varchar(255) NOT NULL,
  `cnpj` varchar(55) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `telefone` varchar(55) DEFAULT NULL,
  `atende_sus` tinyint(1) DEFAULT NULL,
  `id_endereco` int(10) unsigned NOT NULL,
  `valor_consulta` double DEFAULT NULL,
  PRIMARY KEY (`id_clinica`),
  KEY `fk_clinica_endereco_clinica1_idx` (`id_endereco`),
  KEY `index_razao_social` (`razao_social`),
  CONSTRAINT `fk_clinica_endereco_clinica1` FOREIGN KEY (`id_endereco`) REFERENCES `endereco_clinica` (`id_endereco`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clinica`
--

LOCK TABLES `clinica` WRITE;
/*!40000 ALTER TABLE `clinica` DISABLE KEYS */;
INSERT INTO `clinica` VALUES (1,'Clinica Menino Deus','54.853.448/0001-87','menino@gmail.com','(22)2222-2222',1,1,580),(5,'Clinica do Nosso Senhor Jesus','27.461.446/0001-70','jesus@gmail.com','(44)4444-4445',0,5,500),(6,'Highway to Hell',NULL,'hell@gmail.com','(12)2222-2222',1,6,NULL),(7,'Clinica da Nossa Senhora','18.847.136/0001-05','senhora@gmail.com','(33)3333-3333',0,7,1555),(8,'Clinica Pequeno Principe',NULL,'prince@gmail.com','(44)4444-4444',0,8,NULL),(9,'Albert Einstein','16.737.828/0001-67','einstein@gmail.com','(34)3444-4445',1,9,55.55),(10,'Clinica São Jorge','45.111.488/0001-63','saojorge@gmail.com','(48)9798-7987',1,10,NULL),(11,'Clinica Sao Joao','','jorge@gmail.com','',1,11,NULL);
/*!40000 ALTER TABLE `clinica` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-01 14:14:22
